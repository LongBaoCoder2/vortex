mod point;

pub use self::point::Point2d;
