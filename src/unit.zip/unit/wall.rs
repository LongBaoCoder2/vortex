#[derive(Debug, Default)]
pub struct Wall;
