#[derive(Debug, Default)]
pub struct Collectible {}
