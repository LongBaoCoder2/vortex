mod collectible;
mod wall;
mod enemy;
mod player;

pub use self::collectible::Collectible;
pub use self::enemy::Enemy;
pub use self::wall::Wall;
pub use self::player::Player;
