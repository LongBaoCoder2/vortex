#[derive(Default)]
pub struct Wall;